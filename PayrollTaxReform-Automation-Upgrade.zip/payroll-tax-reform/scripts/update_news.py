#!/usr/bin/env python3
"""Fetch official IRS newsroom RSS headlines; publish source links only, never tax advice."""
import datetime as dt
import json
import pathlib
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

ROOT = pathlib.Path(__file__).resolve().parents[1]
DEST = ROOT / 'data' / 'official-updates.json'
FEED = 'https://www.irs.gov/newsroom/rss'
# IRS may change feed URLs; failure preserves existing published data.
SOURCES = [
    ('IRS newsroom', 'https://www.irs.gov/newsroom/rss'),
    ('IRS news releases', 'https://www.irs.gov/newsroom/news-releases-for-current-month'),
]

def fetch_rss(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'PayrollTaxReform/1.0 (official-link-monitor)'})
    with urllib.request.urlopen(req, timeout=18) as response:
        data = response.read(2_000_000)
    root = ET.fromstring(data)
    items = []
    for entry in root.findall('.//item')[:25]:
        title = (entry.findtext('title') or '').strip()
        link = (entry.findtext('link') or '').strip()
        pub = (entry.findtext('pubDate') or '').strip()
        host = (urlparse(link).hostname or '').lower()
        if title and host in ('irs.gov', 'www.irs.gov') and link.startswith('https://'):
            items.append({'title': title[:220], 'url': link, 'published': pub, 'source': 'Internal Revenue Service'})
    return items

def main():
    items = []
    errors = []
    for name, url in SOURCES[:1]:
        try:
            items.extend(fetch_rss(url))
        except Exception as exc:
            errors.append(f'{name}: {type(exc).__name__}: {exc}')
    if not items:
        print('No verified official RSS items found; existing data unchanged. ' + '; '.join(errors))
        return 0
    seen = set()
    unique = []
    for item in items:
        if item['url'] not in seen:
            unique.append(item)
            seen.add(item['url'])
    payload = {'checked_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds'), 'status': 'official-links-only', 'items': unique[:20]}
    DEST.parent.mkdir(exist_ok=True)
    DEST.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'Saved {len(unique[:20])} official links')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
